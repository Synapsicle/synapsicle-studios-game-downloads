export let money=0;
export let gardenLayout=[];
export const gridLength = [5,5];
export const inventory=[]

export function addMoney(value){
    money+=value
}
export function setMoney(value){
    money = value
}