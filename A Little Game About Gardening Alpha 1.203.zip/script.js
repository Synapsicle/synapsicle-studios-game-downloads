import { setupGarden } from './locations/garden.js'
import { setupShop } from './locations/shop.js'
import {setupCredits} from './locations/misc_locations.js'
import {setupCasino} from './locations/casino.js'
import {setupUpgrades} from './locations/upgrades.js'
import { gardenLayout, gridLength,money,addMoney } from './mod.js'
import { plants } from './storage/plants.js'
import { saveGame, loadGame } from './save.js'


const mainArea = document.getElementById('mainArea')
const leftClickMenu =document.createElement('div')
document.addEventListener('keydown', (e) => {
  const key = Number(e.key);
  buttons.forEach((location, index) => {
    if (index + 1 === key) {
      mainArea.innerHTML = "";           
      location.func(mainArea, plants);    
    }
  });
});

document.addEventListener('click', (e) => {
    if (e.button !== 2) {
        leftClickMenu.innerHTML = "";
        leftClickMenu.style.display = 'none';
    }
});

document.addEventListener('contextmenu', (e) => { 
    if(leftClickMenu.style.display==='block'){
      leftClickMenu.style.display="none"
    }
    e.preventDefault();
    leftClickMenu.innerHTML = "";
    
    const showMoney = document.createElement('h2');
    showMoney.textContent = `Money: $${Math.floor(money)}`;
    leftClickMenu.appendChild(showMoney);
    
    if (!document.body.contains(leftClickMenu)) {
        document.body.appendChild(leftClickMenu);
    }
    leftClickMenu.classList.add('left-click-menu')
    leftClickMenu.style.position = 'fixed';
    leftClickMenu.style.left = `${e.clientX}px`;
    leftClickMenu.style.top = `${e.clientY}px`;
    leftClickMenu.style.display = 'block';
    
    console.log('right click');
});



const buttons = [
    { btn: document.getElementById('garden'), func: setupGarden },
    { btn: document.getElementById('shop'), func: setupShop },
    { btn: document.getElementById('Upgrades'), func: setupUpgrades},
    { btn: document.getElementById('casino'), func: setupCasino },
    { btn: document.getElementById('credits'), func: setupCredits },
    
]

function setupGardenArray() {
  if (gardenLayout.length > 0) return;
  
  for (let x = 0; x < gridLength[0]; x++) {
    const row = []; 
    for (let y = 0; y < gridLength[1]; y++) {
      row.push({ cords: [x, y], filled: null }); 
    }
    gardenLayout.push(row);
  }
}


setupGardenArray()
buttons.forEach((location) => {
    location.btn.addEventListener('click', () => {
        mainArea.innerHTML = ""
        location.func(mainArea,plants)
    })
})
if (!loadGame()) addMoney(20)
setInterval(saveGame, 5000)
window.addEventListener('beforeunload', saveGame)
setInterval(()=>{
  if(money<0){
    alert('YOUR BROKE!')
    addMoney(-1*money+20)
  }
},1000)