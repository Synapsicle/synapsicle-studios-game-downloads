import {increaseSpinAmount} from './casino.js'
import {money,addMoney} from '../mod.js'
import { plants } from '../storage/plants.js'
import { setAutoHarvestTier } from './garden.js';

class Upgrade { 
    constructor(name, desc, cost, costMultipier,func ,tier = 0, activated = false) { 
        this.name = name; 
        this.desc = desc; 
        this.activated = activated;
        this.costMultipier=costMultipier 
        this.func=func
        this.cost = cost; 
        this.tier = tier; 
    } 
}
function moneyIncrease(){
    for(let i=0; i<plants.length; i++){
        let currentPlant=plants[i]
        currentPlant.increaseMoney()
    }
}
function fertilizer(){
    const length=plants.length
    console.log(0<length)
    for(let i=0; i<length; i++){
        let currentPlant=plants[i]
        currentPlant.decreaseGrowTime()
        console.log('ran')
    }
    
    console.log('done')
}

export const upgrades = { 
    increaseSpins: new Upgrade('More spins', 'It gives you 5 more total spins.', 200,2,increaseSpinAmount),
    fertilizer: new Upgrade('Fertilizer','Makes the grow time for every plant decrease by 10% for the tier',300,1.75, fertilizer),
    increaseMoney: new Upgrade('Inflation', 'The prices of your crops increase by 10%', 500, 2, moneyIncrease),
    autoHarvest: new Upgrade(
    'Auto Harvest',
    'Automatically harvests one grown cell at a time. Higher tiers increase speed.',
    1000,
    2,
    () => setAutoHarvestTier(upgrades.autoHarvest.tier)
)
};


const tierMap = { 
    0: '○ ○ ○ ○ ○',
    1: '◉ ○ ○ ○ ○', 
    2: '◉ ◉ ○ ○ ○', 
    3: '◉ ◉ ◉ ○ ○', 
    4: '◉ ◉ ◉ ◉ ○', 
    5: '◉ ◉ ◉ ◉ ◉' 
};

function titleScreen() { 
    const titleDiv = document.createElement('div'); 
    titleDiv.classList.add('buyTitle'); 
    
    const title = document.createElement('h1'); 
    title.textContent = "Billy's Upgrades"; 
    
    const subtitle = document.createElement('h2'); 
    subtitle.textContent = '"We love makin things go faster" - Billy Himself'; 
    
    titleDiv.append(title, subtitle); 
    return titleDiv; 
}

function makeUpgrades() { 
    const upgradeDivs = document.createElement('div'); 
    upgradeDivs.style.display='flex'
    for (let key in upgrades) { 
        upgradeDivs.appendChild(makeUpgradePanels(upgrades[key])); 
    } 
    return upgradeDivs; 
}

function makeUpgradePanels(upgrade) { 
    const mainDiv = document.createElement('div'); 
    mainDiv.classList.add('buyBlock'); 
    
    const upgradeName = document.createElement('h2'); 
    upgradeName.textContent = upgrade.name; 
    
    const description = document.createElement('span'); 
    description.textContent = upgrade.desc; 

    const showCost=document.createElement('span')
    showCost.textContent=`$${upgrade.cost}`
    
    const tierIndicator = document.createElement('span'); 
    tierIndicator.textContent = tierMap[upgrade.tier]; 
    
    setInterval(()=>tierIndicator.textContent = tierMap[upgrade.tier], 100 )

    const buyUpgradeButton=document.createElement('button')

    if(upgrade.tier===0){
        buyUpgradeButton.textContent=`Buy ${upgrade.name}`
    }else{
        buyUpgradeButton.textContent=`Upgrade ${upgrade.name}`
    }
        

    buyUpgradeButton.addEventListener('click', () => {
        if (upgrade.tier>=5){
            alert("You've maxed it out")
            return 0
        }
        if(upgrade.cost>money){
            alert(`You can't afford ${upgrade.name}`)
            return 0
        }
        upgrade.tier++
        upgrade.func()
        addMoney(-1*upgrade.cost)
        upgrade.cost=upgrade.costMultipier*=upgrade.cost
        alert(`You've bought ${upgrade.name}`)
    });


    mainDiv.append(upgradeName, description, showCost, tierIndicator,buyUpgradeButton); 
    return mainDiv; 
}

export function setupUpgrades(mainArea) { 
    mainArea.appendChild(titleScreen()); 
    mainArea.appendChild(makeUpgrades()); 
}
export function getUpgradeState(){
  const out = {}
  for (const key in upgrades) {
    const u = upgrades[key]
    out[key] = { tier: u.tier, cost: u.cost, costMultipier: u.costMultipier }
  }
  return out
}

export function setUpgradeState(saved){
  for (const key in saved) {
    if (!upgrades[key]) continue
    upgrades[key].tier = saved[key].tier
    upgrades[key].cost = saved[key].cost
    upgrades[key].costMultipier = saved[key].costMultipier
  }
  // Don't re-run func() for the others. Plant stats are restored directly.
  // Auto harvest is the exception because it needs its interval recreated.
  setAutoHarvestTier(upgrades.autoHarvest.tier)
}