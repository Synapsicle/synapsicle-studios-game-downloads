import { gardenLayout, gridLength, inventory, money, addMoney } from '../mod.js';

const holderDiv = document.createElement('div');
holderDiv.classList.add('popup');
let globalMainArea = null;
const activeIntervals = new Map();

function plant(id, plantItem, loc) {
  if (activeIntervals.has(id)) {
    clearInterval(activeIntervals.get(id));
    activeIntervals.delete(id);
  }

  if (loc.filled.r === undefined) loc.filled.r = 255;
  if (loc.filled.g === undefined) loc.filled.g = 0;

  let cell = document.getElementById(id);
  if (cell) {
    cell.style.backgroundColor = `rgb(${loc.filled.r}, ${loc.filled.g}, 0)`;
  }

  const intervalId = setInterval(() => {
    cell = document.getElementById(id);
    if (!cell) return;

    cell.style.backgroundColor = `rgb(${loc.filled.r}, ${loc.filled.g}, 0)`;

    if (loc.filled.g < 255) {
      loc.filled.g += 5;
    } else if (loc.filled.r > 0) {
      loc.filled.r -= 5;
    } else {
      clearInterval(intervalId);
      activeIntervals.delete(id);
      if (loc.filled) {
        loc.filled.grown = true;
        cell.style.backgroundColor = "rgb(0, 255, 0)";
      }
    }
  }, plantItem.growtime);

  activeIntervals.set(id, intervalId);
}

function loadGridPopup(mouse, mainArea, cellID, cellCords) {
  const location = gardenLayout[cellCords[0]][cellCords[1]];
  if (holderDiv.innerHTML !== "") {
    holderDiv.innerHTML = "";
  }
  holderDiv.style.position = "absolute";
  holderDiv.style.left = mouse.pageX + 'px';
  holderDiv.style.top = mouse.pageY + 'px';
  holderDiv.style.transform = 'translate(-50%, -50%)';

  const title = document.createElement('p');
  const availableInventory = inventory.filter(item => item.amount > 0);

  if (availableInventory.length === 0) {
    title.textContent = "You need some seeds!";
    holderDiv.appendChild(title);
    mainArea.appendChild(holderDiv);
    return;
  }

  title.textContent = "Plant?";
  holderDiv.appendChild(title);

  const list = document.createElement('select');
  availableInventory.forEach((item) => {
    const option = new Option(`${item.name} (${item.amount} left)`, item.id);
    list.appendChild(option);
  });
  holderDiv.appendChild(list);

  const confirmButton = document.createElement('button');
  confirmButton.textContent = 'Plant';
  confirmButton.addEventListener('click', () => {
    const selectedId = list.value;
    const inventoryItem = inventory.find(item => item.id == selectedId);

    if (inventoryItem && inventoryItem.amount > 0) {
      location.filled = { 
        item: inventoryItem, 
        grown: false,
        r: 255,
        g: 0
      };
      inventoryItem.amount -= 1;
      plant(cellID, inventoryItem, location);
    }
    holderDiv.innerHTML = "";
    holderDiv.remove();
  });
  holderDiv.appendChild(confirmButton);
  mainArea.appendChild(holderDiv);
}

export function harvest(loc, id) { 
    if (!loc || !loc.filled) {
        console.warn("Nothing planted here to harvest.");
        return;
    }
    if (!loc.filled.grown) {
        console.warn("This plant isn't fully grown yet!");
        return;
    }

    if (activeIntervals.has(id)) { 
        clearInterval(activeIntervals.get(id)); 
        activeIntervals.delete(id); 
    } 
    
    console.log("Harvested:", loc.filled.item.name); 
    addMoney(loc.filled.item.returnValue); 
    loc.filled = null; 
    console.log(money); 
} 
function loadSideArea() {}

function makeGrid(mainArea) {
  const grid = document.createElement('table');
  for (let x = 0; x < gridLength[0]; x++) {
    const row = document.createElement('tr');
    for (let y = 0; y < gridLength[1]; y++) {
      const column = document.createElement('td');
      column.id = `${x},${y}`;
      const location = gardenLayout[x]?.[y];

      if (location && location.filled) {
        if (location.filled.grown) {
          column.style.backgroundColor = "rgb(0, 255, 0)";
        } else {
          plant(`${x},${y}`, location.filled.item, location);
        }
      } else {
        column.style.backgroundColor = "";
      }

      row.appendChild(column);
      column.addEventListener('click', (e) => {
        e.stopPropagation();
        const currentLocation = gardenLayout[x]?.[y];
        if (!currentLocation) {
          console.error(`No layout data found for coordinates: ${x}, ${y}`);
          return;
        }

        if (currentLocation.filled && currentLocation.filled.grown === true) {
          harvest(currentLocation, `${x},${y}`);
          column.style.backgroundColor = "";
          return;
        }

        if (!currentLocation.filled) {
          loadGridPopup(e, mainArea, `${x},${y}`, [x, y]);
        }
      });
    }
    grid.appendChild(row);
  }
  mainArea.appendChild(grid);
}

export function setupGarden(mainArea) {
  if (mainArea) {
    globalMainArea = mainArea;
    loadSideArea(mainArea);
    makeGrid(mainArea);
  } else {
    console.error("Target mainArea element not found.");
  }
}

window.addEventListener('click', (e) => {
  if (globalMainArea && globalMainArea.contains(holderDiv) && !holderDiv.contains(e.target)) {
    holderDiv.innerHTML = "";
    holderDiv.remove();
  }
});
const autoHarvestSpeeds = {
  1: 5000,
  2: 3000,
  3: 2000,
  4: 1000,
  5: 250
};

let autoHarvestInterval = null;
let nextCellIndex = 0;

export function setAutoHarvestTier(tier) {
  if (autoHarvestInterval !== null) {
    clearInterval(autoHarvestInterval);
    autoHarvestInterval = null;
  }

  if (tier === 0) return;

  autoHarvestInterval = setInterval(() => {
    const totalCells = gridLength[0] * gridLength[1];

    // Search from the next cell, wrapping around the garden.
    for (let i = 0; i < totalCells; i++) {
      const index = (nextCellIndex + i) % totalCells;
      const x = Math.floor(index / gridLength[1]);
      const y = index % gridLength[1];

      const loc = gardenLayout[x]?.[y];
      const id = `${x},${y}`;

      if (loc?.filled?.grown === true) {
        harvest(loc, id);

        const cell = document.getElementById(id);
        if (cell) cell.style.backgroundColor = "";

        // Next time, continue from the following cell.
        nextCellIndex = (index + 1) % totalCells;
        return; // Only harvest ONE cell this tick.
      }
    }
  }, autoHarvestSpeeds[tier]);
}