
import { wipeSave } from '../save.js'

export function setupCredits(mainArea) {
    const creditsDiv = document.createElement('div')

    creditsDiv.innerHTML = `
        <div class="buyBlock">
            <h1>Made by Synapsicle Studios</h1>
            <p>Hosted by CodeHS</p>
            <p>Thanks to everyone that played the Alpha and helped me with the bugfixes.</p>
            <a href="https://twitch.tv/synapsicle">My Twitch</a>
            <a href="https://youtube.com/@SynapsicleStudios">My YouTube</a>

            <h2>Settings</h2>
            <button id="clearData">Clear Save Data</button>
        </div>
    `

    mainArea.appendChild(creditsDiv)

    document.getElementById('clearData').addEventListener('click', () => {
        if (confirm('Are you sure? This will delete your saved game!')) {
            wipeSave()
            location.reload()
        }
    })
}