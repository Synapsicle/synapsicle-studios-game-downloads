import { inventory,money,addMoney } from '../mod.js'; 

function loadSideDiv(){
  const sideDiv=document.createElement('div')
  sideDiv.classList.add('buyTitle')

  const shopInfo=document.createElement('h1')
  shopInfo.textContent="Welcome to the RoseVibe plant shop"
  sideDiv.appendChild(shopInfo)

  const showMoney=document.createElement('h2')
  showMoney.textContent=`Money: $${Math.floor(money)}`
  setInterval(()=>showMoney.textContent=`Money: $${money}`, 100)
  sideDiv.appendChild(showMoney)

  return sideDiv
}



function addPlantToInventory(plant) {
  const existingItem = inventory.find(item => item.id === plant.id);

  if (existingItem) {
    existingItem.amount++;
  } else {
    if (plant.amount === undefined) plant.amount = 1; 
    inventory.push(plant);
  }
}


function addBuyBlock(plant) { 
    const blockDiv = document.createElement('div'); 
    blockDiv.classList.add('buyBlock');
    const name = document.createElement('h2'); 
    name.textContent = plant.name; 
    blockDiv.appendChild(name); 

    const cost=document.createElement('p')
    cost.textContent=`Cost: $${plant.cost}`
    blockDiv.appendChild(cost)

    const buyButton=document.createElement('button')
    buyButton.textContent=`Buy 1 ${plant.name}`

    buyButton.addEventListener('click',()=>{
        if(money<plant.cost){
          alert('You cannnot afford this.')
          return;
        }
        addPlantToInventory(plant)
        addMoney(-1*plant.cost)
    })

    blockDiv.appendChild(buyButton)

    return blockDiv; 
} 

export function setupShop(mainArea, plants) {
  const buyDiv=document.createElement("div") 
  buyDiv.classList.add('shop-blocks')
  plants.forEach((plant, index) => { 
    if(plant.unlocked==false) return 
    const block = addBuyBlock(plant);
    buyDiv.appendChild(block); 
  }); 
  mainArea.appendChild(loadSideDiv())
  mainArea.appendChild(buyDiv);   
}
//addMoney(Infinity)