import { money, addMoney } from '../mod.js'
import { plants } from '../storage/plants.js'
let dailySpins=5
let spinAmount=5
export function increaseSpinAmount(){
  spinAmount+=5
  dailySpins+=5
}

setInterval(()=>{
  dailySpins+=spinAmount
},60000)

let gamebleForPlantCost=5000
function setupTitle() {
  const titleDiv = document.createElement('div')
  titleDiv.classList.add('buyTitle')
  const title = document.createElement('h1')
  title.textContent = 'THE VERDANT CASINO!'
  titleDiv.appendChild(title)
  const subtitle = document.createElement('h2')
  subtitle.textContent = 'The best place to gamble for plants and money!'
  const spins=document.createElement('span')
  spins.textContent=`Spins: ${dailySpins}`
  setInterval(()=>spins.textContent=`Spins: ${dailySpins}`, 100)
  titleDiv.append(subtitle,spins)
  return titleDiv
}

function roulette() {
  const rouletteDiv = document.createElement('div')
  const title = document.createElement('h2')
  const selection = document.createElement('select')
  const confirmWheel = document.createElement('button')
  const bet = document.createElement('input')
  rouletteDiv.classList.add('buyBlock')
  title.textContent = 'Roulette Table'
  confirmWheel.textContent = 'GAMBLE!'
  bet.addEventListener('keydown', (e) => {
    e.stopPropagation()
  })
  bet.type = 'number'
  bet.placeholder = 'Bet amount'
  bet.min = '1'
  const red = new Option("Red", "red")
  const black = new Option("Black", "black")
  const green = new Option("Green", "green")
  selection.add(red)
  selection.add(black)
  selection.add(green)
  confirmWheel.addEventListener('click', () => {
    const userChoice = selection.value
    const betAmount = parseFloat(bet.value) || 0
  if (betAmount <= 20 || money < betAmount) { 
      alert('Please enter a valid bet amount before spinning!'); 
      return; 
  }

    if(dailySpins<=0){
      alert("YOUR OUT OF SPINS!")
      return
    }
    dailySpins--
    const chance = Math.random()
    let winningColor = ''
    if (chance < 0.027) {
      winningColor = 'green'
    } else if (chance < 0.513) {
      winningColor = 'red'
    } else {
      winningColor = 'black'
    }
    if (userChoice === winningColor) {
      const payout = winningColor === 'green' ? betAmount * 35 : betAmount * Math.random()*1.5
      alert(`The wheel landed on ${winningColor.toUpperCase()}. YOU WIN $${payout.toFixed(2)}!`)
      addMoney(payout)
    } else {
      alert(`The wheel landed on ${winningColor.toUpperCase()}. You lost $${betAmount.toFixed(2)}.`)
      addMoney(-betAmount)
    }
  })
  rouletteDiv.append(title, selection, bet, confirmWheel)
  return rouletteDiv
}
function pickChest(chest){
  if(money<1000){
    alert('You don\'t have enought money for this')
    return
  }
  const pickedChest=Math.floor(Math.random()*3)

  if(chest===pickedChest){
    alert('YOU WON!!!')
    addMoney(1500)
    return
  }
  alert('you lost')
  dailySpins--
  addMoney(-1000)
}

function pick3Chests() {
  const div = document.createElement('div');
  div.classList.add('buyBlock');

  const title = document.createElement('h2');
  title.textContent = 'Pick a chest';

  const showCost = document.createElement('span');
  showCost.textContent = 'Cost: $1K';

  div.append(title, showCost);
  for (let i = 0; i < 3; i++) {
    const button = document.createElement('button');
    button.textContent = `Pick ${i + 1} chest`;

    button.addEventListener('click', () => {
      pickChest(i);
    });

    div.append(button);
  }

  
  return div;
}

function gamblingPlants() {
  if (money < gamebleForPlantCost) {
    alert("You don't have enough money!")
    return
  }
  const lockedPlants = plants.filter(plant => !plant.unlocked)
  if (lockedPlants.length === 0) {
    alert("You have already unlocked every single plant!")
    return
  }

  addMoney(-1*gamebleForPlantCost)
  gamebleForPlantCost=gamebleForPlantCost*1.25

  const chosenPlant = lockedPlants[Math.floor(Math.random() * lockedPlants.length)]
  chosenPlant.unlocked = true
  alert(`YOU HAVE JUST UNLOCKED ${chosenPlant.name.toUpperCase()}`)
}

function gambleForPlants() {
  const div = document.createElement('div')
  const title = document.createElement('h2')
  const unlocked = document.createElement('button')
  div.classList.add('buyBlock')
  title.textContent = `Gamble for a new plant species ($${Math.round(gamebleForPlantCost/1000)}k)`
  unlocked.textContent = 'GAMBLE!'
  unlocked.addEventListener('click', gamblingPlants)
  div.append(title, unlocked)
  return div
}
function buySpins(){
  const mainDiv=document.createElement('div')
  mainDiv.classList.add('buySpins')

  const text=document.createElement('span')
  text.textContent="Buy more Spins (100$)"

  const buyButton=document.createElement('button')
  buyButton.textContent="Buy!"
  buyButton.addEventListener('click',()=>{
    if(money>=100){
      dailySpins+=1
    }
  })

  mainDiv.appendChild(text)
  mainDiv.appendChild(buyButton)

  return mainDiv
}
export function setupCasino(mainArea) {
  mainArea.appendChild(setupTitle())
  const gamblingArea = document.createElement('div')
  gamblingArea.style.display = "flex"

  gamblingArea.append(roulette(),pick3Chests(), gambleForPlants(),buySpins())

  mainArea.appendChild(gamblingArea)
}
export function getCasinoState(){
  return { dailySpins, spinAmount, gamebleForPlantCost }
}

export function setCasinoState(s){
  dailySpins = s.dailySpins
  spinAmount = s.spinAmount
  gamebleForPlantCost = s.gamebleForPlantCost
}