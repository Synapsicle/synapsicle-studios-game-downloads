class Plant { 
    constructor(name, growtime, cost, returnValue, id ,unlocked=false) { 
        this.name = name; 
        this.growtime = growtime*10; // in MS 
        this.cost = cost; 
        this.returnValue = returnValue; 
        this.id = id; 
        this.amount = 0; 
        this.unlocked=unlocked 
    } 
    decreaseGrowTime(){
        let tenPercent=Math.floor(this.growtime*0.1)
        this.growtime-=tenPercent
    }
    increaseMoney(){
        let tenPercent=Math.floor(this.returnValue*0.1)
        this.growtime-=tenPercent
    }
}


/*
-----Order of properties-----
name
growtime (How long it takes to grow)
cost (Buy cost)
returnValue (money you get from harvesting)
id (continues increasing)
amount (how much seeds you have)
unlocked (if the plant is unlocked by default)
*/

export const plants = [
    new Plant('Tulip', 2,5,7.5,31,true),
    new Plant('Strawberry', 3, 6, 12, 1, true),
    new Plant('Lettuce', 3.5, 10, 16, 2, true),
    new Plant('Carrot', 4, 25, 42, 3, true),
    new Plant('Tomato', 5, 80, 140, 4),
    new Plant('Onion', 5.5, 120, 220, 21), 
    new Plant('Corn', 6, 200, 360, 5),
    new Plant('Potato', 6.5, 500, 950, 6),
    new Plant('Blueberry', 8, 1500, 3000, 7),
    new Plant('Watermelon', 8.5, 4000, 8500, 8),
    new Plant('Pumpkin', 9, 8000, 23000, 9),
    new Plant('Cacao Bean', 9.5, 10000, 29000, 22), 
    new Plant('Lychee', 10, 12000, 35000, 10), 
    new Plant('Pineapple', 11, 20000, 60000, 11),
    new Plant('Dragonfruit', 12, 35000, 110000, 12),
    new Plant('Avocado', 13.5, 55000, 180000, 13),
    new Plant('Passionfruit', 15, 85000, 300000, 14),
    new Plant('Mango', 16.5, 105000, 380000, 23),
    new Plant('Glowshroom', 18, 130000, 480000, 15),
    new Plant('Starfruit', 22, 200000, 800000, 16),
    new Plant('Golden Apple', 26, 350000, 1500000, 17),
    new Plant('Moonflower', 30, 600000, 2800000, 18),
    new Plant('Crystal Lotus', 32.5, 800000, 3800000, 24),
    new Plant('Plasma Berry', 35, 1000000, 5000000, 19),
    new Plant('Solar Flare Orchid', 40, 1750000, 9500000, 25),
    new Plant('Omni Tree', 45, 2500000, 15000000, 20),
    new Plant('Chronos Vine', 50, 4500000, 30000000, 26),
    new Plant('Void Root', 52.5, 7000000, 50000000, 27),
    new Plant('Cosmic Pepper', 55, 12000000, 90000000, 28),
    new Plant('Nebula Sprout', 58, 20000000, 160000000, 29),
    new Plant('Yggdrasil Seedling', 60, 35000000, 300000000, 30),
];