import { money, setMoney, gardenLayout, inventory } from './mod.js'
import { plants } from './storage/plants.js'
import { getCasinoState, setCasinoState } from './locations/casino.js'
import { getUpgradeState, setUpgradeState } from './locations/upgrades.js'

const KEY = 'gardenSave_v1'

export function saveGame(){
  try {
    const data = {
      version: 1,
      savedAt: Date.now(),
      money,
      plants: plants.map(p => ({
        id: p.id, unlocked: p.unlocked, growtime: p.growtime,
        returnValue: p.returnValue, amount: p.amount
      })),
      inventoryIds: inventory.map(i => i.id),
      garden: gardenLayout.map(row => row.map(cell =>
        cell.filled
          ? { itemId: cell.filled.item.id, grown: cell.filled.grown, r: cell.filled.r, g: cell.filled.g }
          : null
      )),
      upgrades: getUpgradeState(),
      casino: getCasinoState()
    }
    localStorage.setItem(KEY, JSON.stringify(data))
  } catch (e) {
    console.warn('Save failed', e)
  }
}

// Returns true if a save was loaded, false if this is a new game.
export function loadGame(){
  let data
  try {
    data = JSON.parse(localStorage.getItem(KEY))
  } catch (e) { return false }
  if (!data || data.version !== 1) return false

  setMoney(data.money)

  for (const s of data.plants) {
    const p = plants.find(pl => pl.id === s.id)
    if (!p) continue
    p.unlocked = s.unlocked
    p.growtime = s.growtime
    p.returnValue = s.returnValue
    p.amount = s.amount
  }

  inventory.length = 0
  for (const id of data.inventoryIds) {
    const p = plants.find(pl => pl.id === id)
    if (p) inventory.push(p)   // same object as in plants, as in the shop
  }

  data.garden.forEach((row, x) => row.forEach((s, y) => {
    const cell = gardenLayout[x]?.[y]
    if (!cell) return
    const item = s && plants.find(pl => pl.id === s.itemId)
    cell.filled = item ? { item, grown: s.grown, r: s.r, g: s.g } : null
  }))

  setUpgradeState(data.upgrades)
  setCasinoState(data.casino)
  return true
}

export function wipeSave(){
  localStorage.removeItem(KEY)
  location.reload()
  
}